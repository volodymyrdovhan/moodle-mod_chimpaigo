<?php
$string['pluginname'] = 'chimpAIgo';
$string['modulename'] = 'chimpAIgo';
$string['modulenameplural'] = 'chimpAIgo';
$string['modulename_help'] = 'Activity that launches the chimpAIgo! LTI 1.3 tool.';
$string['privacy:metadata'] = 'This module sends LTI data to the chimpAIgo! provider through Moodle.';
$string['chimpaigoname'] = 'Name';
$string['pluginadministration'] = 'chimpAIgo administration';
$string['view_launch'] = 'Open chimpAIgo';
$string['event_activity_viewed'] = 'chimpAIgo activity viewed';
