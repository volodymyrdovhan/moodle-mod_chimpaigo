<?php
$string['pluginname'] = 'chimpAIgo';
$string['modulename'] = 'chimpAIgo';
$string['modulenameplural'] = 'chimpAIgo';
$string['modulename_help'] = 'Actividad que lanza la herramienta LTI 1.3 chimpAIgo!';
$string['privacy:metadata'] = 'Este módulo envía datos LTI al proveedor chimpAIgo! a través de Moodle.';
$string['chimpaigoname'] = 'Nombre';
$string['pluginadministration'] = 'Administración de chimpAIgo';
$string['view_launch'] = 'Abrir chimpAIgo';
$string['event_activity_viewed'] = 'Actividad chimpAIgo vista';
